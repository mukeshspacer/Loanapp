-- ============================================================
-- Loan Finance Management System - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS loan_finance CHARACTER SET utf8mb4;
USE loan_finance;

-- ---------------- Users (login) ----------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role ENUM('admin','staff') DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default admin login -> username: admin / password: admin123
INSERT INTO users (username, password, full_name, role)
VALUES ('admin', '$2y$10$Ug6z1z2yQ2n1r1a5g8p2ZO7Xk3nQ1v9m8Cq2c1F1lQpQeD9F9F9Fa', 'Administrator', 'admin')
ON DUPLICATE KEY UPDATE username = username;
-- NOTE: password hash above is a placeholder. Run backend/generate_hash.php
-- once to create a real bcrypt hash for 'admin123' and update this row.

-- ---------------- Members ----------------
CREATE TABLE IF NOT EXISTS members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    address TEXT,
    aadhaar VARCHAR(20),
    photo VARCHAR(255),
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------- Loans ----------------
CREATE TABLE IF NOT EXISTS loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    loan_number VARCHAR(20) NOT NULL UNIQUE,
    member_id INT NOT NULL,
    loan_amount DECIMAL(12,2) NOT NULL,
    interest_rate DECIMAL(5,2) NOT NULL,
    tenure_months INT NOT NULL,
    emi_amount DECIMAL(12,2) NOT NULL,
    loan_date DATE NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('Active','Closed','Overdue') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- ---------------- EMI Schedule / Collection ----------------
CREATE TABLE IF NOT EXISTS emi_payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    installment_no INT NOT NULL,
    due_date DATE NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    paid_amount DECIMAL(12,2) DEFAULT 0,
    paid_date DATE NULL,
    status ENUM('Pending','Paid','Overdue') DEFAULT 'Pending',
    FOREIGN KEY (loan_id) REFERENCES loans(id)
);

-- ---------------- Receipt Vouchers (money received) ----------------
CREATE TABLE IF NOT EXISTS receipt_vouchers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    receipt_no VARCHAR(20) NOT NULL UNIQUE,
    receipt_date DATE NOT NULL,
    member_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_mode ENUM('Cash','Bank','UPI','Cheque') DEFAULT 'Cash',
    remarks VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- ---------------- Payment Vouchers (money paid out) ----------------
CREATE TABLE IF NOT EXISTS payment_vouchers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voucher_no VARCHAR(20) NOT NULL UNIQUE,
    voucher_date DATE NOT NULL,
    paid_to VARCHAR(100) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    purpose VARCHAR(255),
    payment_mode ENUM('Cash','Bank','UPI','Cheque') DEFAULT 'Cash',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------- Settings ----------------
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(150) DEFAULT 'My Finance Company',
    company_logo VARCHAR(255),
    default_interest_rate DECIMAL(5,2) DEFAULT 12.00
);

INSERT INTO settings (id, company_name, default_interest_rate)
VALUES (1, 'My Finance Company', 12.00)
ON DUPLICATE KEY UPDATE id = id;
