<?php $current = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar" id="sidebar">
    <div class="brand"><i class="fa-solid fa-building-columns"></i> <?= htmlspecialchars($settings['company_name']) ?></div>
    <a href="dashboard.php" class="<?= $current=='dashboard.php'?'active':'' ?>"><i class="fa-solid fa-gauge"></i> Dashboard</a>
    <a href="members.php" class="<?= $current=='members.php'?'active':'' ?>"><i class="fa-solid fa-users"></i> Members</a>
    <a href="loans.php" class="<?= $current=='loans.php'?'active':'' ?>"><i class="fa-solid fa-hand-holding-dollar"></i> Loans</a>
    <a href="emi.php" class="<?= $current=='emi.php'?'active':'' ?>"><i class="fa-solid fa-money-check-dollar"></i> EMI Collection</a>
    <a href="receipt.php" class="<?= $current=='receipt.php'?'active':'' ?>"><i class="fa-solid fa-receipt"></i> Receipt Voucher</a>
    <a href="payment.php" class="<?= $current=='payment.php'?'active':'' ?>"><i class="fa-solid fa-file-invoice-dollar"></i> Payment Voucher</a>
    <a href="ledger.php" class="<?= $current=='ledger.php'?'active':'' ?>"><i class="fa-solid fa-book"></i> Cash Book / Ledger</a>
    <a href="reports.php" class="<?= $current=='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-line"></i> Reports</a>
    <a href="settings.php" class="<?= $current=='settings.php'?'active':'' ?>"><i class="fa-solid fa-gear"></i> Settings</a>
    <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>
<div class="main-content">
    <div class="topbar">
        <button class="btn btn-sm btn-outline-secondary d-md-none" onclick="document.getElementById('sidebar').classList.toggle('open')">
            <i class="fa-solid fa-bars"></i>
        </button>
        <h4><?= $pageTitle ?? '' ?></h4>
        <div class="text-muted small">
            <i class="fa-solid fa-user-circle"></i> <?= htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']) ?>
        </div>
    </div>
