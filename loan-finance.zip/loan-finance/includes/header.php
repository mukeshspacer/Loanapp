<?php
require_once __DIR__ . '/../backend/db.php';
require_login();

$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$settings = $stmt->fetch() ?: ['company_name' => 'My Finance Company'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($settings['company_name']) ?> | <?= $pageTitle ?? 'Dashboard' ?></title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="app-wrapper">
