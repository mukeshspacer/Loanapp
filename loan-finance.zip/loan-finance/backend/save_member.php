<?php
require_once 'db.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../members.php');
    exit;
}

$name    = trim($_POST['name']);
$mobile  = trim($_POST['mobile']);
$address = trim($_POST['address'] ?? '');
$aadhaar = trim($_POST['aadhaar'] ?? '');
$status  = $_POST['status'] ?? 'Active';
$id      = $_POST['id'] ?? null;

// Handle photo upload (optional)
$photoName = null;
if (!empty($_FILES['photo']['name'])) {
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $photoName = 'member_' . time() . '.' . $ext;
    move_uploaded_file($_FILES['photo']['tmp_name'], __DIR__ . '/../assets/images/' . $photoName);
}

if ($id) {
    // Update existing member
    if ($photoName) {
        $stmt = $pdo->prepare("UPDATE members SET name=?, mobile=?, address=?, aadhaar=?, status=?, photo=? WHERE id=?");
        $stmt->execute([$name, $mobile, $address, $aadhaar, $status, $photoName, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE members SET name=?, mobile=?, address=?, aadhaar=?, status=? WHERE id=?");
        $stmt->execute([$name, $mobile, $address, $aadhaar, $status, $id]);
    }
} else {
    // Insert new member with auto-generated code (MEM0001, MEM0002, ...)
    $code = next_code($pdo, 'members', 'member_code', 'MEM');
    $stmt = $pdo->prepare("INSERT INTO members (member_code, name, mobile, address, aadhaar, photo, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$code, $name, $mobile, $address, $aadhaar, $photoName, $status]);
}

header('Location: ../members.php');
exit;
