<?php
require_once 'db.php';
require_login();

$type = $_GET['type'] ?? 'receipt';
$id = $_GET['id'];

$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();

if ($type === 'receipt') {
    $stmt = $pdo->prepare("SELECT r.*, m.name AS party_name FROM receipt_vouchers r JOIN members m ON r.member_id = m.id WHERE r.id = ?");
    $stmt->execute([$id]);
    $v = $stmt->fetch();
    $title = 'Receipt Voucher';
    $voucherNo = $v['receipt_no'];
    $date = $v['receipt_date'];
    $partyLabel = 'Received From';
    $partyName = $v['party_name'];
    $purposeLabel = 'Remarks';
    $purpose = $v['remarks'];
} else {
    $stmt = $pdo->prepare("SELECT * FROM payment_vouchers WHERE id = ?");
    $stmt->execute([$id]);
    $v = $stmt->fetch();
    $title = 'Payment Voucher';
    $voucherNo = $v['voucher_no'];
    $date = $v['voucher_date'];
    $partyLabel = 'Paid To';
    $partyName = $v['paid_to'];
    $purposeLabel = 'Purpose';
    $purpose = $v['purpose'];
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?= $title ?> - <?= htmlspecialchars($voucherNo) ?></title>
<style>
body { font-family: Arial, sans-serif; padding: 40px; color: #111; }
.header { text-align: center; border-bottom: 3px solid #2563eb; padding-bottom: 16px; margin-bottom: 24px; }
.header h1 { margin: 0; color: #2563eb; }
table { width: 100%; border-collapse: collapse; margin-top: 20px; }
td { padding: 10px; border-bottom: 1px solid #ddd; }
td.label { font-weight: bold; width: 200px; }
.amount-box { margin-top: 30px; padding: 16px; background: #f3f4f6; border-radius: 8px; font-size: 1.3rem; font-weight: bold; text-align: center; }
.sign { margin-top: 60px; display: flex; justify-content: space-between; }
.sign div { border-top: 1px solid #333; width: 200px; text-align: center; padding-top: 6px; }
@media print { .no-print { display: none; } }
</style>
</head>
<body>
<div class="no-print" style="text-align:right;margin-bottom:16px;">
    <button onclick="window.print()">Print</button>
</div>
<div class="header">
    <h1><?= htmlspecialchars($settings['company_name']) ?></h1>
    <h3><?= $title ?></h3>
</div>
<table>
    <tr><td class="label">Voucher No.</td><td><?= htmlspecialchars($voucherNo) ?></td></tr>
    <tr><td class="label">Date</td><td><?= $date ?></td></tr>
    <tr><td class="label"><?= $partyLabel ?></td><td><?= htmlspecialchars($partyName) ?></td></tr>
    <tr><td class="label"><?= $purposeLabel ?></td><td><?= htmlspecialchars($purpose) ?></td></tr>
    <tr><td class="label">Payment Mode</td><td><?= $v['payment_mode'] ?></td></tr>
</table>
<div class="amount-box">Amount: ₹<?= number_format($v['amount'], 2) ?></div>
<div class="sign">
    <div>Prepared By</div>
    <div>Authorized Signatory</div>
</div>
</body>
</html>
