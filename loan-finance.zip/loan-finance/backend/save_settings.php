<?php
require_once 'db.php';
require_login();

$companyName = trim($_POST['company_name']);
$rate = $_POST['default_interest_rate'];

$logoName = null;
if (!empty($_FILES['company_logo']['name'])) {
    $ext = pathinfo($_FILES['company_logo']['name'], PATHINFO_EXTENSION);
    $logoName = 'logo_' . time() . '.' . $ext;
    move_uploaded_file($_FILES['company_logo']['tmp_name'], __DIR__ . '/../assets/images/' . $logoName);
}

if ($logoName) {
    $stmt = $pdo->prepare("UPDATE settings SET company_name=?, default_interest_rate=?, company_logo=? WHERE id=1");
    $stmt->execute([$companyName, $rate, $logoName]);
} else {
    $stmt = $pdo->prepare("UPDATE settings SET company_name=?, default_interest_rate=? WHERE id=1");
    $stmt->execute([$companyName, $rate]);
}

header('Location: ../settings.php');
exit;
