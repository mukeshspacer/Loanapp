<?php
require_once 'db.php';
require_login();

$filter = $_GET['filter'] ?? 'today';
$customDate = $_GET['date'] ?? date('Y-m-d');
$format = $_GET['format'] ?? 'excel';

if ($filter === 'today') {
    $dateCond = "= CURDATE()";
} elseif ($filter === 'month') {
    $dateCond = "BETWEEN DATE_FORMAT(CURDATE(),'%Y-%m-01') AND LAST_DAY(CURDATE())";
} else {
    $dateCond = "= " . $pdo->quote($customDate);
}

$receipts = $pdo->query("SELECT receipt_date AS date, amount, 'Receipt' AS type, remarks AS note FROM receipt_vouchers WHERE receipt_date $dateCond")->fetchAll();
$payments = $pdo->query("SELECT voucher_date AS date, amount, 'Payment' AS type, purpose AS note FROM payment_vouchers WHERE voucher_date $dateCond")->fetchAll();
$entries = array_merge($receipts, $payments);
usort($entries, fn($a, $b) => strcmp($a['date'], $b['date']));

if ($format === 'excel') {
    // Excel-compatible CSV export
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="cash_book.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Date', 'Type', 'Note', 'Amount']);
    foreach ($entries as $e) {
        fputcsv($out, [$e['date'], $e['type'], $e['note'], $e['amount']]);
    }
    fclose($out);
} else {
    // Simple printable HTML that the user can "Save as PDF" from the browser print dialog
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Cash Book PDF</title>";
    echo "<style>body{font-family:Arial;padding:30px} table{width:100%;border-collapse:collapse} td,th{border:1px solid #ccc;padding:6px;font-size:13px}</style>";
    echo "</head><body><h2>Cash Book</h2><script>window.onload=()=>window.print()</script><table><tr><th>Date</th><th>Type</th><th>Note</th><th>Amount</th></tr>";
    foreach ($entries as $e) {
        echo "<tr><td>{$e['date']}</td><td>{$e['type']}</td><td>" . htmlspecialchars($e['note']) . "</td><td>₹" . number_format($e['amount'],2) . "</td></tr>";
    }
    echo "</table></body></html>";
}
