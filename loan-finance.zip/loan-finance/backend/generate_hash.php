<?php
// Run this once (visit generate_hash.php in browser) to get a real password hash.
// Then copy the output into the users table 'password' column via phpMyAdmin.
$password = 'admin123'; // change if you want a different password
echo "Hash for '$password': <br><br>";
echo password_hash($password, PASSWORD_DEFAULT);
echo "<br><br>Copy this hash and run:<br>";
echo "<code>UPDATE users SET password='" . password_hash($password, PASSWORD_DEFAULT) . "' WHERE username='admin';</code>";
