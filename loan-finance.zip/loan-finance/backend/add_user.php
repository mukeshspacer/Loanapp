<?php
require_once 'db.php';
require_login();

$username = trim($_POST['username']);
$fullName = trim($_POST['full_name'] ?? '');
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$role = $_POST['role'] ?? 'staff';

$stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, role) VALUES (?, ?, ?, ?)");
$stmt->execute([$username, $password, $fullName, $role]);

header('Location: ../settings.php');
exit;
