<?php
require_once 'db.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../emi.php');
    exit;
}

$emi_id  = $_POST['emi_id'];
$loan_id = $_POST['loan_id'];
$amount  = $_POST['amount'];
$search  = $_POST['loan_search'] ?? '';

$pdo->beginTransaction();
try {
    // Update the EMI row
    $stmt = $pdo->prepare("SELECT * FROM emi_payments WHERE id = ?");
    $stmt->execute([$emi_id]);
    $emi = $stmt->fetch();

    $newPaid = $emi['paid_amount'] + $amount;
    $status = $newPaid >= $emi['amount'] ? 'Paid' : 'Pending';

    $stmt = $pdo->prepare("UPDATE emi_payments SET paid_amount = ?, paid_date = CURDATE(), status = ? WHERE id = ?");
    $stmt->execute([$newPaid, $status, $emi_id]);

    // Get member for this loan
    $stmt = $pdo->prepare("SELECT member_id FROM loans WHERE id = ?");
    $stmt->execute([$loan_id]);
    $member_id = $stmt->fetchColumn();

    // Auto-create a receipt voucher for this collection
    $receiptNo = next_code($pdo, 'receipt_vouchers', 'receipt_no', 'RCT');
    $stmt = $pdo->prepare("INSERT INTO receipt_vouchers (receipt_no, receipt_date, member_id, amount, payment_mode, remarks)
                            VALUES (?, CURDATE(), ?, ?, 'Cash', 'EMI Collection')");
    $stmt->execute([$receiptNo, $member_id, $amount]);

    // If all installments for the loan are paid, close the loan
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM emi_payments WHERE loan_id = ? AND status != 'Paid'");
    $stmt->execute([$loan_id]);
    if ($stmt->fetchColumn() == 0) {
        $stmt = $pdo->prepare("UPDATE loans SET status = 'Closed' WHERE id = ?");
        $stmt->execute([$loan_id]);
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    die("Error collecting EMI: " . $e->getMessage());
}

header('Location: ../emi.php?q=' . urlencode($search));
exit;
