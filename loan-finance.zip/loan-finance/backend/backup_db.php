<?php
require_once 'db.php';
require_login();

// Requires mysqldump to be available on the server and in the system PATH.
$DB_HOST = 'localhost';
$DB_NAME = 'loan_finance';
$DB_USER = 'root';
$DB_PASS = '';

$filename = 'backup_' . date('Y-m-d_His') . '.sql';
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$command = "mysqldump --host=" . escapeshellarg($DB_HOST) .
            " --user=" . escapeshellarg($DB_USER) .
            (empty($DB_PASS) ? '' : " --password=" . escapeshellarg($DB_PASS)) .
            " " . escapeshellarg($DB_NAME);

passthru($command);
