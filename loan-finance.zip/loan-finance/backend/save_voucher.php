<?php
require_once 'db.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../dashboard.php');
    exit;
}

$type = $_POST['type'];

if ($type === 'receipt') {
    $receiptNo = next_code($pdo, 'receipt_vouchers', 'receipt_no', 'RCT');
    $stmt = $pdo->prepare("INSERT INTO receipt_vouchers (receipt_no, receipt_date, member_id, amount, payment_mode, remarks)
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $receiptNo,
        $_POST['voucher_date'],
        $_POST['member_id'],
        $_POST['amount'],
        $_POST['payment_mode'],
        $_POST['remarks'] ?? ''
    ]);
    header('Location: ../receipt.php');
} else {
    $voucherNo = next_code($pdo, 'payment_vouchers', 'voucher_no', 'PMT');
    $stmt = $pdo->prepare("INSERT INTO payment_vouchers (voucher_no, voucher_date, paid_to, amount, purpose, payment_mode)
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $voucherNo,
        $_POST['voucher_date'],
        $_POST['paid_to'],
        $_POST['amount'],
        $_POST['purpose'] ?? '',
        $_POST['payment_mode']
    ]);
    header('Location: ../payment.php');
}
exit;
