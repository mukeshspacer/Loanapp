<?php
require_once 'db.php';
require_login();

$id = $_GET['id'];
$settings = $pdo->query("SELECT * FROM settings LIMIT 1")->fetch();

$stmt = $pdo->prepare("SELECT l.*, m.name, m.mobile, m.address, m.aadhaar FROM loans l JOIN members m ON l.member_id = m.id WHERE l.id = ?");
$stmt->execute([$id]);
$loan = $stmt->fetch();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Loan Agreement - <?= htmlspecialchars($loan['loan_number']) ?></title>
<style>
body { font-family: Arial, sans-serif; padding: 40px; color: #111; line-height: 1.7; }
.header { text-align: center; border-bottom: 3px solid #2563eb; padding-bottom: 16px; margin-bottom: 24px; }
.header h1 { margin: 0; color: #2563eb; }
table { width: 100%; border-collapse: collapse; margin: 20px 0; }
td { padding: 8px; border-bottom: 1px solid #ddd; }
td.label { font-weight: bold; width: 220px; }
.sign { margin-top: 60px; display: flex; justify-content: space-between; }
.sign div { border-top: 1px solid #333; width: 220px; text-align: center; padding-top: 6px; }
@media print { .no-print { display: none; } }
</style>
</head>
<body>
<div class="no-print" style="text-align:right;margin-bottom:16px;">
    <button onclick="window.print()">Print</button>
</div>
<div class="header">
    <h1><?= htmlspecialchars($settings['company_name']) ?></h1>
    <h3>Loan Agreement</h3>
</div>

<p>This Loan Agreement is made and entered into on <strong><?= $loan['loan_date'] ?></strong> between
<strong><?= htmlspecialchars($settings['company_name']) ?></strong> ("the Lender") and
<strong><?= htmlspecialchars($loan['name']) ?></strong> ("the Borrower"), residing at
<?= htmlspecialchars($loan['address']) ?>, holding Aadhaar No. <?= htmlspecialchars($loan['aadhaar']) ?>.</p>

<table>
    <tr><td class="label">Loan Number</td><td><?= htmlspecialchars($loan['loan_number']) ?></td></tr>
    <tr><td class="label">Borrower Name</td><td><?= htmlspecialchars($loan['name']) ?></td></tr>
    <tr><td class="label">Mobile Number</td><td><?= htmlspecialchars($loan['mobile']) ?></td></tr>
    <tr><td class="label">Loan Amount</td><td>₹<?= number_format($loan['loan_amount'], 2) ?></td></tr>
    <tr><td class="label">Interest Rate</td><td><?= $loan['interest_rate'] ?>% per annum</td></tr>
    <tr><td class="label">Tenure</td><td><?= $loan['tenure_months'] ?> months</td></tr>
    <tr><td class="label">Monthly EMI</td><td>₹<?= number_format($loan['emi_amount'], 2) ?></td></tr>
    <tr><td class="label">Loan Date</td><td><?= $loan['loan_date'] ?></td></tr>
    <tr><td class="label">First Due Date</td><td><?= $loan['due_date'] ?></td></tr>
</table>

<p>The Borrower agrees to repay the above loan amount along with applicable interest in equal monthly
installments as specified above. Failure to pay any installment by its due date may attract late fees
as per the Lender's policy. This agreement is governed by mutual consent of both parties.</p>

<div class="sign">
    <div>Borrower Signature</div>
    <div>Lender / Authorized Signatory</div>
</div>
</body>
</html>
