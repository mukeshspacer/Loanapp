<?php
// ============================================================
// Database connection
// Update these 4 values to match your MySQL server
// ============================================================
$DB_HOST = 'localhost';
$DB_NAME = 'loan_finance';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Start session on every page that includes this file
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Helper: block access if not logged in (call at top of protected pages)
function require_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
}

// Helper: generate next sequential code like MEM0001, LN0001, RCT0001
function next_code($pdo, $table, $column, $prefix) {
    $stmt = $pdo->query("SELECT $column FROM $table ORDER BY id DESC LIMIT 1");
    $last = $stmt->fetchColumn();
    $num = 1;
    if ($last) {
        $num = intval(substr($last, strlen($prefix))) + 1;
    }
    return $prefix . str_pad($num, 4, '0', STR_PAD_LEFT);
}
