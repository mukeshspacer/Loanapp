<?php
require_once 'db.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../loans.php');
    exit;
}

$member_id     = $_POST['member_id'];
$loan_amount   = $_POST['loan_amount'];
$interest_rate = $_POST['interest_rate'];
$tenure        = $_POST['tenure_months'];
$emi_amount    = $_POST['emi_amount'];
$loan_date     = $_POST['loan_date'];
$due_date      = $_POST['due_date'];

$loan_number = next_code($pdo, 'loans', 'loan_number', 'LN');

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare("INSERT INTO loans (loan_number, member_id, loan_amount, interest_rate, tenure_months, emi_amount, loan_date, due_date, status)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Active')");
    $stmt->execute([$loan_number, $member_id, $loan_amount, $interest_rate, $tenure, $emi_amount, $loan_date, $due_date]);
    $loan_id = $pdo->lastInsertId();

    // Auto-generate the EMI schedule, one row per month starting at due_date
    $stmt2 = $pdo->prepare("INSERT INTO emi_payments (loan_id, installment_no, due_date, amount) VALUES (?, ?, ?, ?)");
    $date = new DateTime($due_date);
    for ($i = 1; $i <= $tenure; $i++) {
        $stmt2->execute([$loan_id, $i, $date->format('Y-m-d'), $emi_amount]);
        $date->modify('+1 month');
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    die("Error saving loan: " . $e->getMessage());
}

header('Location: ../loans.php');
exit;
