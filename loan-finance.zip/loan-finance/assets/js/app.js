// ============================================================
// Loan Finance Management System - Shared JS helpers
// ============================================================

// Auto-hide bootstrap alerts after 4 seconds
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.alert').forEach(function (alertEl) {
        setTimeout(function () {
            alertEl.style.transition = 'opacity 0.4s';
            alertEl.style.opacity = '0';
            setTimeout(() => alertEl.remove(), 400);
        }, 4000);
    });
});

// Confirm before any destructive action (delete links use onclick="return confirm(...)"
// already, this is a fallback for anything using class="confirm-delete")
document.addEventListener('click', function (e) {
    if (e.target.closest('.confirm-delete')) {
        if (!confirm('Are you sure? This action cannot be undone.')) {
            e.preventDefault();
        }
    }
});
